import { EmployeesService } from './../services/employees.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

title="Employees CRUD App";
employees:any[];
employee:any;
message="";
add=false;
save=false;


  constructor(private es:EmployeesService) {
    console.log("EmployeesComponent created....");

   }

   ngOnInit() {
    console.log("EmployeesComponent initialized");
       this.getAllEmployees();

  }
  ngOnDestroy() {
    console.log("EmployeesComponent destroyed");

  }
  

  getAllEmployees(){

    this.es.getAllEmployees()
           .subscribe(response=>this.employees=response,error=>this.message=error);

  }

  editEmployee(id:number){

    this.add=true;
    this.save=false;

    console.log("edit",id);
    this.es.getEmployee(id)
           .subscribe(response=>this.employee=response,error=>this.message=error);

  }


  deleteEmployee(id:number){
    console.log("delete",id);
    this.es.deleteEmployee(id)
           .subscribe(response=>{
             this.employees=response;
            
          },error=>this.message=error);

  }


  
  addEmployee(){
    this.es.addEmployee(this.employee)
           .subscribe(response=>this.employees=response,error=>this.message=error);
  }

  updateEmployee(){
    this.es.updateEmployee(this.employee.id,this.employee)
           .subscribe(response=>this.employees=response,error=>this.message=error);
  }

  newEmployee(){
    this.add=false;
    this.save=true;
    
    this.employee={id:0,name:'',email:'',dob:new Date()};
  }

}
