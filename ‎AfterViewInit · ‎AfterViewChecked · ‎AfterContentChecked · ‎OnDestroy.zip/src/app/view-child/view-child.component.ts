import { FgColorDirective } from './../directives/fg-color.directive';
import { StopWatchComponent } from './../stop-watch/stop-watch.component';
import { NumberComponent } from './../number/number.component';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements OnInit {

  @ViewChild(NumberComponent)
  private numberComponent: NumberComponent;

  @ViewChild(StopWatchComponent)
  private stopwatchComponent: StopWatchComponent;

  @ViewChild(FgColorDirective)
    private fgColorDirective: FgColorDirective;


    @ViewChild('name') 
    private name : ElementRef;
 
    @ViewChild('city') 
    private city : ElementRef;
    

    fcolor='grey';

  increase() {
     this.numberComponent.increaseByOne();
  }
  
  decrease() {
     this.numberComponent.decreaseByOne();
  }

  constructor() { }

  ngOnInit() {
  }

  startStopwatch() {
    this.stopwatchComponent.start();
}
stopStopwatch() {
    this.stopwatchComponent.stop();
}


changeColor(color: string) {
  this.fgColorDirective.setBgColor(color);
  console.log("In ChangeColor :"+color);
}

changeColorOfNameAndCity() {
  this.name.nativeElement.style.backgroundColor = 'cyan';
  this.name.nativeElement.style.color = 'red';	   
  this.city.nativeElement.style.backgroundColor = 'cyan';
  this.city.nativeElement.style.color = 'red';	
}

}
