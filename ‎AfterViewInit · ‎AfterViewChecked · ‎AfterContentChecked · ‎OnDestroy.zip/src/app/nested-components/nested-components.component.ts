import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested-components',
  templateUrl: './nested-components.component.html',
  styleUrls: ['./nested-components.component.css']
})
export class NestedComponentsComponent implements OnInit {


  title='Nested Component Demo';

  constructor() {
    console.log("NestedComponentsComponent created...");

   }

  ngOnInit() {
    console.log("NestedComponentsComponent initialized...");
    
  }
  
  ngOnDestroy() {
    console.log("NestedComponentsComponent destroyed...");
    
  }

  ngOnChanges() {
    console.log("NestedComponentsComponent :ngOnChanges...");
    
  }

  ngAfterContentInit() {
    console.log("NestedComponentsComponent :ngAfterContentInit...");
    
  }
  ngAfterContentChecked() {
    console.log("NestedComponentsComponent :ngAfterContentChecked()...");
    
  }

  ngAfterViewInit() {
    console.log("NestedComponentsComponent :ngAfterViewInit()...");
    
  }
  ngAfterViewChecked() {
    console.log("NestedComponentsComponent :ngAfterViewChecked()...");
    
  }


}
