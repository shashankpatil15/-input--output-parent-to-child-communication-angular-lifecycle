import { Component, OnInit } from '@angular/core';
import { PhotosService } from '../services/photos.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.css']
})
export class PhotosComponent implements OnInit {
  title='Photos';
  photos:any[];
  albumId:number;
  message="";
  
    constructor(private ps:PhotosService,private route:ActivatedRoute) {
  
      console.log("PhotosComp created...."+this.albumId);
  
     }
  
    ngOnInit() {
  
      this.route.queryParams.subscribe(params=>{
        this.albumId=params.albumId;
      })
      console.log("PhotosComp initialized...."+this.albumId);
  
      if(this.albumId)
      this.getAllPhotosByAlbumId();
      else
      this.getAllPhotos();
  
  
      }
  
  ngOnDestroy(){
    console.log("PostsComp destroyed...."+this.albumId);
  }
    
  
      getAllPhotos(){
        this.ps.getAllPhotos().subscribe(response=>this.photos=response,error=>this.message=error);
        }
  
        getAllPhotosByAlbumId(){
          this.ps.getAllPhotosAlbumId(this.albumId).subscribe(response=>this.photos=response,error=>this.message=error);
          }
            
}
