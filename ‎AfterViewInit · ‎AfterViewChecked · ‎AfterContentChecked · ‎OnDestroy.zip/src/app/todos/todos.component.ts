import { Component, OnInit } from '@angular/core';
import { TodosService } from '../services/todos.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {

  title='todos';
  todos:any[];
  userId:number;
  message="";

  constructor(private ts:TodosService,private route:ActivatedRoute) {

    console.log("TodosComp created...."+this.userId);
   }

  ngOnInit() {

    this.route.queryParams.subscribe(params=>{
      this.userId=params.userId;
    })
    console.log("todosComp initialized...."+this.userId);

    if(this.userId)
    this.getAllTodosByUserId();
    else
    this.getAllTodos();


    }

ngOnDestroy(){
  console.log("todosComp destroyed...."+this.userId);
}
  

    getAllTodos(){
      this.ts.getAllTodos().subscribe(response=>this.todos=response,error=>this.message=error);
      }

      getAllTodosByUserId(){
        this.ts.getAllTodosByUserId(this.userId).subscribe(response=>this.todos=response,error=>this.message=error);
        }
}
