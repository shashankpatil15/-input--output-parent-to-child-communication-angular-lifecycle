import { Component, OnInit } from '@angular/core';
import { AlbumsService } from '../services/albums.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit {

  title='albums';
  albums:any[];
  userId:number;
  message="";

  constructor(private as:AlbumsService,private route:ActivatedRoute) {

    console.log("albumsComp created...."+this.userId);
   }

  ngOnInit() {

    this.route.queryParams.subscribe(params=>{
      this.userId=params.userId;
    })
    console.log("albumssComp initialized...."+this.userId);

    if(this.userId)
    this.getAllAlbumsByUserId();
    else
    this.getAllAlbums();


    }

ngOnDestroy(){
  console.log("albumssComp destroyed...."+this.userId);
}
  

    getAllAlbums(){
      this.as.getAllAlbums().subscribe(response=>this.albums=response,error=>this.message=error);
      }

      getAllAlbumsByUserId(){
        this.as.getAllAlbumByUserId(this.userId).subscribe(response=>this.albums=response,error=>this.message=error);
        }


}
