import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.css']
})
export class StateComponent implements OnInit {
  
  name='Maharashtra';

  @Input()
  countryName='';

  cityName='';

  @Output()
  stateChanged=new EventEmitter<string>();

  @Output()
  cityChanged=new EventEmitter<String>();
  

  constructor() { }

  ngOnInit() {
  }

  sendState(){
    this.stateChanged.emit(this.name);
  }

  send(value){
    this.cityName=value;
    this.cityChanged.emit(value);
  }


}
