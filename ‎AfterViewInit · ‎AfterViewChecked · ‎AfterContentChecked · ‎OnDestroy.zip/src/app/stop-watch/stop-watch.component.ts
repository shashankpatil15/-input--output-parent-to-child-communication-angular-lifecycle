import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stop-watch',
  templateUrl: './stop-watch.component.html',
  styleUrls: ['./stop-watch.component.css']
})
export class StopWatchComponent implements OnInit {
  shouldRun:boolean = false;
	counter:number = 0;
	start() {
	      this.shouldRun = true;
	      let interval = setInterval(() =>
  	        {  
		    if(this.shouldRun === false){
			   clearInterval(interval);
		    }
		    this.counter = this.counter + 1;			
	        }, 1000);
	}
	stop() {
	      this.shouldRun = false;
	}
  constructor() { }

  ngOnInit() {
  }

}
