import { Directive, ElementRef, Renderer2, Input } from '@angular/core';

@Directive({
  selector: '[fgColor]'
})
export class FgColorDirective {

  

  constructor(private el:ElementRef,private r:Renderer2) {
    console.log("BgColor Directive created.....");
   }

   @Input()
   set fgColor(color:string){
    console.log("In setFgColor :"+color); 
    this.r.setStyle(this.el.nativeElement,"color",color);
     }

     
     setBgColor(color:string){
      this.r.setStyle(this.el.nativeElement,"color",color);
     }
  
}
