import { PagerService } from './../services/pager.service';
import { Component, OnInit } from '@angular/core';
import { CommentsService } from '../services/comments.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  title='comments';
  comments:any[];
  userId:number;
  message="";


  // pager object
      pager: any = {};
 
      // paged items
      pagedItems: any[];
   
  constructor(private cs:CommentsService,private route:ActivatedRoute,private pagerService:PagerService) {

    console.log("CommentsComp created...."+this.userId);
   }

  ngOnInit() {

    this.route.queryParams.subscribe(params=>{
      this.userId=params.postId;
    })
    console.log("commentsComp initialized...."+this.userId);

    if(this.userId)
    this.getAllCommentsByPostId();
    else
    this.getAllComments();


    }

ngOnDestroy(){
  console.log("commentsComp destroyed...."+this.userId);
}
  

    getAllComments(){
      this.cs.getAllComments().subscribe(response=>
        {this.comments=response;
        this.setPage(1);
        },error=>this.message=error);
      }

      getAllCommentsByPostId(){
        this.cs.getAllCommentsByPostId(this.userId).subscribe(response=>{this.comments=response;
          this.setPage(1);
        },error=>this.message=error);
        }



        
        setPage(page: number) {
          // get pager object from service
          this.pager = this.pagerService.getPager(this.comments.length, page);
   
          // get current page of items
          this.pagedItems = this.comments.slice(this.pager.startIndex, this.pager.endIndex + 1);
      }
}
